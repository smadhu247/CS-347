import time
import tkinter as tk
import datetime 
import pandas as pd
import os

class InformationLog:
    ##############################################################################################################
    ##  Information Log Class: Creates and stores information logs with information about the train trip
    ##############################################################################################################
   

    def __init__(self, entry, **saved):
        """ 
            InformationLog constructor
                entry:      list entry to be added to the log
                saved:      dictionary where logs are saved
        """
        self.entry = entry
        self.saved = saved
        
    def getCurrentLog(self):
        """ 
            Gets the current log for the trip 
        """
        print("Todays log: ", self.saved)
        return self.saved.setdefault(datetime.datetime.now())
        

    def createNewLog(self, d, humid_sensor, precip_sensor, wheel_sensor, gps_sensor, dis_sensor):
        """ 
            Creates a new log for the trip by getting current data from sensors
        """
        rain = precip_sensor.getRain()
        snow = precip_sensor.getSnow()
        distance = dis_sensor.getDistance()
        humidity = humid_sensor.getHumdidity()
        wheelspeed = wheel_sensor.getWheelSpeed()
        speed = gps_sensor.getGPSSpeed()

        self.saved.update({d: [ "Rain Data: " + str(rain), 
                                "Snow Data: " + str(snow), 
                                "Distance Data: " + str(distance), 
                                "Humidity Data: " + str(humidity), 
                                "Wheel Speed Data: " + str(wheelspeed), 
                                "GPS Speed Data: " + str(speed) ]
                        })


class HumiditySensor:
    ##############################################################################################################
    ##  Humidity Sensor Class: Collects information from the humidity sensor
    ##############################################################################################################

    def __init__(self, humidty):
        """ 
            HumiditySensor constructor
                humidty:    int humidity level detected by sensor
        """
        self.humidty = humidty

    def getHumdidity(self):
        """ 
            Gets humidity level from the humidity sensor
        """
        return self.humidty


class GPSSensor:
    ##############################################################################################################
    ##  GPS Sensor Class: Collects information from the GPS sensor
    ##############################################################################################################

    def __init__(self, GPS_speed, GPS_connection, gate):
        """ 
            GPSSensor constructor
                GPS_speed:      int GPS speed level detected by sensor
                GPS_connection: bool connection detected by sensor
                gate:           bool gate checker that detects locations of gates    
        """
        self.GPS_speed = GPS_speed
        self.gate = gate
        self.GPS_connection = GPS_connection

    def getGate(self):
        """ 
            Checks whether there's a gate in the path of the train
        """
        return self.gate
    
    def getGPSSpeed(self):
        """ 
            Gets the GPS speed from the GPS speed sensor
        """
        if (self.GPS_connection == False):
            return False
        if (self.GPS_connection == True):
            return self.GPS_speed


class WheelSensor:
    ##############################################################################################################
    ##   Wheel Sensor Class: Collects information from the wheel sensor
    ##############################################################################################################

    def __init__(self, rotations_per_min):
        """ 
            WheelSensor constructor
                rotations_per_min:      int rotations per minute detected by sensor 
        """
        self.rotations_per_min = rotations_per_min

    def getWheelSpeed(self):
        """ 
            Gets the wheel speed from the wheel sensor
        """
        return self.rotations_per_min

class PrecipitationSensor:
    ##############################################################################################################
    ##  Precipitation Sensor Class: Collects information from the precipitation sensor
    ##############################################################################################################

    def __init__(self, precip_level, temperature, rain, snow):
        """ 
            PrecipitationSensor constructor
                precip_level:   int precipitation level detected by sensor 
                temperature:    int temperature detected by sensor 
                rain:           bool rain checker
                snow:           bool snow checker
        """
        self.precip_level = precip_level
        self.temperature = temperature
        self.rain = False
        self.snow = False

    def getWeather(self):
        """ 
            Checks whether there is rain or snow when precipitation is detected
        """
        if (self.precip_level > 4 and self.temperature < 32):
            self.snow = True
            self.rain = False
        else:
            self.snow = False
            self.rain = True
            
    def getRain(self):
        """ 
            Checks if there is rain from the precipitation sensor
        """
        PrecipitationSensor.getWeather(self)
        return self.rain

    def getSnow(self):
        """ 
            Checks if there is snow from the precipitation sensor
        """
        PrecipitationSensor.getWeather(self)
        return self.snow    

class DistanceSensor:
    ##############################################################################################################
    ##  Distance Sensor Class: Collects information from the distance sensor
    ##############################################################################################################

    def __init__(self, distance):
        """ 
            DistanceSensor constructor
                distance: int distance away from closest object detected by sensor 
        """
        self.distance = distance

    def getDistance(self):
        return self.distance

class Display:
    ##############################################################################################################
    ##  Display Class: Displays notifications and warnings to the conductor
    ############################################################################################################## 

    def displayWarning(warning):
        """ 
            Displays warning for the conductor
        """
        print(warning)
    
    def displayNotification(notif):
        """ 
            Displays notification for the conductor
        """
        print(notif)


class IotEngine():

    ##############################################################################################################
    ##  IotEngine Class: Performs calculations with data collected from the sensors to display reccomendations to the conductor. 
    ##############################################################################################################

    is_on = False
    admin = False
    conductor = False
    is_logged_on = False

    conductor_username = "conductor"
    conductor_password = "password"
    admin_username = "admin"
    admin_password = "password"

   
    def loginAdmin(self):
        """ 
            Logs the administrator into the IoT Engine
        """
        print("************** ADMIN LOGGED IN **************")
        time.sleep(2)
        print("IoT Engine calibrating...\n")
        time.sleep(1)
        self.admin = True
        self.is_logged_on = True
        self.is_on = True

   
    def loginConductor(self):
        """ 
            Logs the conductor into the IoT Engine
        """
        print("************** CONDUCTOR LOGGED IN **************")
        time.sleep(2)
        print("IoT Engine calibrating...\n")
        time.sleep(1)
        self.conductor = True
        self.is_logged_on = True
        self.is_on = True

    
    def calculateDistance(self, dis_sensor):
        """ 
            Calculates the distance away from the closest object and sends
            a notification or warning to the conductor
        """
        distance = dis_sensor.getDistance()
        if (distance > 1000):
            notif = "Object more than 1000 feet away."
            Display.displayNotification(notif)
        else:
            warning = "Object is " + str(distance) + " feet away."
            Display.displayWarning(warning)

   
    def calculateSlippage(self, humid_sensor, precip_sensor, wheel_sensor, gps_sensor):
        """ 
            Calculates the if there is slippage and sends a notification 
            or warning to the conductor
        """
        rain = precip_sensor.getRain()
        snow = precip_sensor.getSnow()
        wheelspeed = wheel_sensor.getWheelSpeed()
        gpsspeed = gps_sensor.getGPSSpeed()
        humidity = humid_sensor.getHumdidity()

        slipping = False
        speed = wheelspeed * 33 * 3.14 * 60 / 63360

        if (abs(speed - gpsspeed) > 5):
            slipping = True
        if (humidity > 50):
            slipping = True
        if (rain == True):
            slipping = True
        if (snow == True):
            slipping = True
        if (slipping):
            warning = "Slippage is occurring"
            Display.displayWarning(warning)
        else:
            notif = "No slippage"
            Display.displayNotification(notif)

  
    def checkGates(self, dis_sensor, gps_sensor):
        """ 
            Checks if a gate is nearby and sends a notification or warning 
            to the conductor
        """
        distance = dis_sensor.getDistance()
        gate = gps_sensor.getGate()

        near = False

        if (distance < 1000):
            near = True
        if (gate and near):
            warning = "Gate is " + str(distance) + " feet away."
            Display.displayWarning(warning)
        else:
            notif = "No gates nearby"
            Display.displayNotification(notif)

   
    def tsnr(self):
        """ 
            Grabs data from sensors (csv file) and initializes lists to hold data.
            Allows admin to view logs
            Allows conductor to start a new trip 
        """
        cwd = os.getcwd() + '/sensordata.csv'
        df = pd.read_csv(cwd)
        df = df.dropna()

        dist_list = []
        wheel_list = []
        humid_list = []
        precip_list = []
        temp_list = []
        gps_list = []
        gate_list = []

        for i in range(len(df)):
            dist_list.append(df["Object Distance"][i])
            wheel_list.append(df["Wheel Speed"][i])
            humid_list.append(df["Humidity"][i])
            precip_list.append(df["Precipitation Level"][i])
            temp_list.append(df["Temperature"][i])
            gps_list.append(df["GPS Speed"][i])
            gate_list.append(df["Gate"][i])

        invalid_login = True
        while (invalid_login):
            print("************** WELCOME **************")
            username = input("Enter a username: ")
            password = input("Enter a password: ")
            if (username == self.conductor_username and password == self.conductor_password):
                self.loginConductor()
                invalid_login = False
            if (username == self.admin_username and password == self.admin_password):
                self.loginAdmin()
                invalid_login = False
            if (invalid_login == True):
                print("Invalid Login. Try Again.")

        
        if (self.admin):
            old_logs = {}
            now = datetime.datetime.now()
            infolog = InformationLog(now, **old_logs)
            infolog.getCurrentLog()
        
        if (self.conductor): 
            values = len(df)
            iter_val = 0
            old_logs = {}

            while (values > 0):        
                precipsensor = PrecipitationSensor(precip_list[iter_val],
                                                    temp_list[iter_val],
                                                    False,
                                                    False)
                dissensor = DistanceSensor(dist_list[iter_val])
                humidsensor = HumiditySensor(humid_list[iter_val])
                wheelsensor = WheelSensor(wheel_list[iter_val])
                gpssensor = GPSSensor(gps_list[iter_val], True, gate_list[iter_val])

                now = datetime.datetime.now()

                print("Current time: ", now)
                self.calculateDistance(dissensor)
                self.calculateSlippage(humidsensor, precipsensor, wheelsensor, gpssensor)
                self.checkGates(dissensor, gpssensor)
                print(" ")

                time.sleep(1)

                infolog = InformationLog(now, **old_logs)
                infolog.createNewLog(now, humidsensor, precipsensor, wheelsensor, gpssensor, dissensor)

                values = values - 1
                iter_val = iter_val + 1
            
            print("Thank you for riding\n") 
        
        self.is_on = False

iot = IotEngine()
iot.tsnr()